pub fn tuple_unzip(items: Vec<Coordinate>) -> (Vec<i32>, Vec<i32>) {
    todo!()
}

pub fn tuple_zip(items: (Vec<i32>, Vec<i32>)) -> Vec<Coordinate> {
    todo!()
}
