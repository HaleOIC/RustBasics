pub struct Direction {
    pub x: i32,
    pub y: i32
}

pub enum CardinalDirection {
    North,
    East,
    South,
    West
}
